﻿namespace IntroductionToAJAX.Models
{
    public class InputModel
    {
        public string ZIPCode { get; set; }
    }
}