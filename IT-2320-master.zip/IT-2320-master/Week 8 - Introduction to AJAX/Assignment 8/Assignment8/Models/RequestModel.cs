﻿namespace Assignment8.Models
{
    public class RequestModel
    {
        public int PlayerNumber;
    }
}