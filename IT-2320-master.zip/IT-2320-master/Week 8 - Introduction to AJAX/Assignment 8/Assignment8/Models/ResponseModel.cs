﻿using System.Collections.Generic;

namespace Assignment8.Models
{
    public class ResponseModel
    {
        public int PlayerNumber;
        public string PlayerName;
    }
}