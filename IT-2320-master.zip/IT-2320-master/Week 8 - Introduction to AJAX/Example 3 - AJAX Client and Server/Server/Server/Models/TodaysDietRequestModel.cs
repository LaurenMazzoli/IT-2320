﻿namespace Server.Models
{
    public class TodaysDietRequestModel
    {
        public int MyWeight { get; set; }
    }
}