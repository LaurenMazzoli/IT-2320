﻿namespace FinalProject.Models
{
    public class GetAccountInformationRequestModel
    {
        public string Username { get; set; }
    }
}