﻿namespace FinalProject.Models
{
    public class HomeViewModel
    {
    }
}