﻿namespace FinalProject.Models
{
    public class CreateAccountRequestModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string EmailAdd { get; set; }
        public string EmailCon { get; set; }
    }
}