﻿using System.Collections.Generic;

namespace JavaScriptSerializer.Models
{
    public class HomeModel
    {
        public string RawData { get; set; }
        public List<Person> People { get; set; }
    }
}