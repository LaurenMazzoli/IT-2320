/*
 * ITMP-2650 Java Programming, Summer 2014
 * Instructor: Martin P. Walsh
 * Student Name: John Doe  (replace John Doe with your student name)
 * Homework Assignment: Chap 1, Problem 1-99 (replace Chap 1, Problem 1-99 with the assignment you are submitting)
 * Purpose of Assignment: To show students homework assignment format (briefly describe the purpose of the assignment here)
 * 
 */

package itmp2650homeworkassignmentexample;

import java.util.Scanner;

public class ITMP2650HomeworkAssignmentExample 
{

    public static void main(String[] args) 
    {
        // this header information will display at the beginning of the output when the Jar file is executed
        System.out.println("ITMP-2650 Java Programming");
        // replace John Doe with your student name
        System.out.println("Student Name: John Doe");
        // replace Chapter 1, Problem 1-99 with the homeword assignment you are submitting
        System.out.println("Homework Assignment: Chapter 1, Problem 1-99");
        System.out.println("________________________________");
        System.out.println("");
        
        
        Scanner keyboard = new Scanner(System.in);
        String firstName;
        String lastName;
        String combineNames;
        
        System.out.println("Enter Your First Name");
        firstName = keyboard.nextLine();
        System.out.println("Enter Your Last Name");
        lastName = keyboard.nextLine();
        combineNames = firstName + " " + lastName;
        System.out.println("Hello " + combineNames);
        
    }
    
}
