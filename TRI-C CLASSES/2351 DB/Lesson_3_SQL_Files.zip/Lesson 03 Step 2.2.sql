 -- Lesson 03 Step 1.2 
 
SELECT 
    CONCAT(worker.last_name,
            ', ',
            worker.first_name) AS Employee,
    department_name AS Department,
    worker.department_number AS 'Department #',
    CONCAT(managers.last_name,
            ', ',
            managers.first_name) AS Boss
FROM
    ex.employees AS worker
        INNER JOIN
    ex.departments ON worker.department_number = departments.department_number
        INNER JOIN
    ex.employees AS managers ON worker.manager_id = managers.employee_id
ORDER BY worker.last_name, worker.first_name

