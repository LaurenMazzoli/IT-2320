-- Lesson 03 Step 1.1

SELECT 
    account_number AS 'Acct Num',
    account_description AS Description
FROM
    ap.general_ledger_accounts
ORDER BY account_description 