SELECT 
    *
FROM
    ap.vendors
WHERE
    vendor_state IN ('DC' , 'NJ', 'WI')
ORDER BY vendor_state , vendor_city;