-- Lesson 03 Step 1.3 

SELECT 
    CONCAT(last_name, ', ', first_name) AS 'Vendor Name'
FROM
    vendor_contacts
ORDER BY last_name, first_name