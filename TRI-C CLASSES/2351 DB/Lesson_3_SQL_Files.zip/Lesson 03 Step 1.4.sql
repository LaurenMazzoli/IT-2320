-- Lesson 03 Step 1.14

SELECT DISTINCT
    vendor_name AS Vendor
FROM
    ap.vendors
        INNER JOIN
    invoices ON vendors.vendor_id = invoices.vendor_id
ORDER BY vendor_name