-- Lesson 03 Step 2.1


SELECT 
    CONCAT(last_name, ', ', first_name) AS Employee,
    department_name AS Department
FROM
    ex.employees
        INNER JOIN
    ex.departments ON employees.department_number = departments.department_number
ORDER BY last_name, first_name
