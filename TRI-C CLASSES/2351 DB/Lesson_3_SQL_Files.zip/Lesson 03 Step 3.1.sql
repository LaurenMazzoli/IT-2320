-- Lesson 03 Step 2.1

SELECT 
    vendor_name AS Vendor,
    invoice_number AS 'Invoice#',
    invoice_date AS Date,
    invoice_total AS Total
FROM
    ap.vendors
        LEFT OUTER JOIN
    ap.invoices ON vendors.vendor_id = invoices.vendor_id
WHERE
    invoice_total > 250
    AND invoice_date BETWEEN '2014-04-01' AND '2014-05-01'
ORDER BY invoice_total DESC