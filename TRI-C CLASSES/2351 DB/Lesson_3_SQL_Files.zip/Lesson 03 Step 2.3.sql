-- Lesson 03 Step 2.3

SELECT 
    department_name AS Department,
    CONCAT(last_name, ', ', first_name) AS Employee
FROM
    ex.departments
        LEFT OUTER JOIN
    ex.employees ON departments.department_number = employees.department_number
ORDER BY department_name